function flux = F(U)
%calculate x flux

V = decoder2d(U);
flux = zeros(4,1);
flux(1) = V(1)*V(2);
flux(2) = V(1)*V(2)*V(2)+V(4);
flux(3) = V(1)*V(2)*V(3);
flux(4) = (U(4)+V(4))*V(2);

end