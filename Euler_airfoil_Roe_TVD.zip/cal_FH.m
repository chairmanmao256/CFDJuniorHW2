function FH = cal_FH(U,FH,vect,edge,idim,jdim)
for j=1:1:jdim % bear in mind that the virtual points are included, index is
% volume index!!
    for i=1:1:idim
        % switch cases, take care of boundaries
        if i==1
            UL = reshape(U(idim,j+1,:),[4,1]);
            ULL = reshape(U(idim-1,j+1,:),[4,1]);
            UR = reshape(U(1,j+1,:),[4,1]);
            URR = reshape(U(2,j+1,:),[4,1]);
        elseif i==2
            UL = reshape(U(1,j+1,:),[4,1]);
            ULL = reshape(U(idim,j+1,:),[4,1]);
            UR = reshape(U(2,j+1,:),[4,1]);
            URR = reshape(U(3,j+1,:),[4,1]);
        elseif i==idim
            UL = reshape(U(idim-1,j+1,:),[4,1]);
            ULL = reshape(U(idim-2,j+1,:),[4,1]);
            UR = reshape(U(idim,j+1,:),[4,1]);
            URR = reshape(U(1,j+1,:),[4,1]);
        else
            UL = reshape(U(i-1,j+1,:),[4,1]);
            ULL = reshape(U(i-2,j+1,:),[4,1]);
            UR = reshape(U(i,j+1,:),[4,1]);
            URR = reshape(U(i+1,j+1,:),[4,1]);
        end
        
        % reconstruction--simplified version
        UL0 = UL+0.5*minmod(UL-ULL,UR-UL);
        UR0 = UR-0.5*minmod(URR-UR,UR-UL);
        
        % Calculate the flux
        % Calculate the normal vector
        nn = reshape(vect(i,j,:),[8,1]);
        nh1 = nn(1:2,1);
        edge4 = reshape(edge(i,j,:),[4,1]);
        normh1 = edge4(1);
        
        avg = roe2d(UL0,UR0);% roe's average
        c = sqrt(1.4*avg(4)/avg(1));
        if max(abs(imag(avg)))>1e-8
           disp(['Error encountered during Roe average, FH , index: ',num2str(i),'  ' ,num2str(j)]) 
        end
        
        % eigens
        lam1 = abs(avg(2)*nh1(1)+avg(3)*nh1(2)-c);
        lam2 = abs(avg(2)*nh1(1)+avg(3)*nh1(2));
        lam3 = lam2;
        lam4 = abs(avg(2)*nh1(1)+avg(3)*nh1(2)+c);
        
        %A coefficients
        delU = decoder2d(UR0) - decoder2d(UL0);
        A(1) = 1/(2*c*c)*(delU(4)-avg(1)*c*(delU(2)*nh1(1)+delU(3)*nh1(2)));
        A(2) = 1/c*avg(1)*(-delU(2)*nh1(2)+delU(3)*nh1(1));
        A(3) = 1/(c*c)*(c*c*delU(1)-delU(4));
        A(4) = 1/(2*c*c)*(delU(4)+avg(1)*c*(delU(2)*nh1(1)+delU(3)*nh1(2)));
        
        % right eigen vectors
        Havg = 1.4/0.4*avg(4)/avg(1)+0.5*(avg(2)*avg(2)+avg(3)*avg(3));
%         Havg = 1.4/0.4*avg(4)/avg(1);
        qavg = avg(2)*nh1(1)+avg(3)*nh1(2);
        ravg = -avg(2)*nh1(2)+avg(3)*nh1(1);
        
        r1 = [1,avg(2)-c*nh1(1),avg(3)-c*nh1(2),Havg-c*qavg]';
        r2 = [0,-c*nh1(2),c*nh1(1),c*ravg]';
        r3 = [1,avg(2),avg(3),0.5*(avg(2)*avg(2)+avg(3)*avg(3))]';
        r4 = [1,avg(2)+c*nh1(1),avg(3)+c*nh1(2),Havg+c*qavg]';
        
        %left and right Flux vector
        HL = (F(UL0)*nh1(1)+G(UL0)*nh1(2))*normh1;
        HR = (F(UR0)*nh1(1)+G(UR0)*nh1(2))*normh1;
        
        
        % assemble the flux vector
        sum = (lam1*A(1)*r1 + lam2*A(2)*r2 +lam3*A(3)*r3+lam4*A(4)*r4)*normh1/2;
        FH(i,j,:) = (HL+HR)*0.5 - sum;
    end
end
for j = 1:1:jdim
    FH(idim+1,j,:) = FH(1,j,:);
end
end