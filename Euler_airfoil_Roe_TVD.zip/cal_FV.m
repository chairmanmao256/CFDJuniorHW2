function FV = cal_FV(U,FV,UV,vect,edge,idim,jdim)
% calculate the flux in eta direction
% boundary condition is not treated here!!! that is to say, j index only
% sweeps from 2 to jdim(Virtual points are used to calcualte 2 and jdim)

for i = 1:1:idim
    for j=2:1:jdim % volume index is used here
        if j>=2
            UR =reshape(U(i,j+1,:),[4,1]);
            URR = reshape(U(i,j+2,:),[4,1]);
            UL = reshape(U(i,j,:),[4,1]);
            ULL = reshape(U(i,j-1,:),[4,1]);
        else
            UR =reshape(U(i,j+1,:),[4,1]);
            URR = reshape(U(i,j+2,:),[4,1]);
            UL = reshape(U(i,j,:),[4,1]);
            ULL = UV(:,i);
        end
        
        
        % reconstruction--simplified version
        UL0 = UL+0.5*minmod(UL-ULL,UR-UL);
        UR0 = UR-0.5*minmod(URR-UR,UR-UL);
        
        % Calculate the flux
        % Calculate the normal vector
        nn = reshape(vect(i,j,:),[8,1]);
        nv1 = nn(5:6,1);
        edge4 = reshape(edge(i,j,:),[4,1]);
        normv1 = edge4(3);
        
        avg = roe2d(UL0,UR0);% roe's average
        if max(abs(imag(avg)))>1e-8
           disp(['Error encountered during Roe average, FV , index: ',num2str(i),'  ' ,num2str(j)]) 
        end
        c = sqrt(1.4*avg(4)/avg(1));
        
        % eigens
        lam1 = abs(avg(2)*nv1(1)+avg(3)*nv1(2)-c);
        lam2 = abs(avg(2)*nv1(1)+avg(3)*nv1(2));
        lam3 = lam2;
        lam4 = abs(avg(2)*nv1(1)+avg(3)*nv1(2)+c);
        
        %A coefficients
        delU = decoder2d(UR0) - decoder2d(UL0);
        A(1) = 1/(2*c*c)*(delU(4)-avg(1)*c*(delU(2)*nv1(1)+delU(3)*nv1(2)));
        A(2) = 1/c*avg(1)*(-delU(2)*nv1(2)+delU(3)*nv1(1));
        A(3) = 1/(c*c)*(c*c*delU(1)-delU(4));
        A(4) = 1/(2*c*c)*(delU(4)+avg(1)*c*(delU(2)*nv1(1)+delU(3)*nv1(2)));
        
        % right eigen vectors
        Havg = 1.4/0.4*avg(4)/avg(1)+0.5*(avg(2)*avg(2)+avg(3)*avg(3));
%         Havg = 1.4/0.4*avg(4)/avg(1);
        qavg = avg(2)*nv1(1)+avg(3)*nv1(2);
        ravg = -avg(2)*nv1(2)+avg(3)*nv1(1);
        
        r1 = [1,avg(2)-c*nv1(1),avg(3)-c*nv1(2),Havg-c*qavg]';
        r2 = [0,-c*nv1(2),c*nv1(1),c*ravg]';
        r3 = [1,avg(2),avg(3),0.5*(avg(2)*avg(2)+avg(3)*avg(3))]';
        r4 = [1,avg(2)+c*nv1(1),avg(3)+c*nv1(2),Havg+c*qavg]';
        
        %left and right Flux vector
        HL = (F(UL0)*nv1(1)+G(UL0)*nv1(2))*normv1;
        HR = (F(UR0)*nv1(1)+G(UR0)*nv1(2))*normv1;
        
        
        % assemble the flux vector
        sum = (lam1*A(1)*r1 + lam2*A(2)*r2 +lam3*A(3)*r3+lam4*A(4)*r4)*normv1/2;
        FV(i,j,:) = (HL+HR)*0.5 - sum;
        
    end
end

end