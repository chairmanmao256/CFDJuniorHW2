function FV = cal_FV_central(U,FV,x,y,idim,jdim)
% calculate the flux in eta direction,using central scheme