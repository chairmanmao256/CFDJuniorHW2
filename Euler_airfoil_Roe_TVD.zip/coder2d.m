function U = coder2d(V)
rho = V(1);
u = V(2);
v = V(3);
p = V(4);

% if rho<=0
%     disp('Error! rho is smaller than 0!!!')
% end
% 
% if p<=0
%     disp('Error! p is smaller than 0 !!!')
% end

U = zeros(4,1);
U(1) = rho;
U(2) = rho*u;
U(3) = rho*v;
U(4) = rho*(p/rho/(1.4-1)+0.5*(u*u+v*v));

end