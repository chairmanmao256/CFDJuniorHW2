function V = decoder2d(U)
V = zeros(4,1);
V(1) = U(1);
V(2) = U(2)/U(1);
V(3) = U(3)/U(1);
V(4) = (U(4)/V(1)-0.5*(V(2)*V(2)+V(3)*V(3)))*V(1)*0.4;
end