function U = euler_airfoil(M,alpha,CFL,step,mode,restart,restep)

% --------read grid-----------
fileID=fopen('grid.dat','r');
dim = fscanf(fileID,'   %d    %d\n',[1 2]);
idim=dim(1)-1;
jdim=dim(2)-1;
x = zeros(idim+1,jdim+1);
y = zeros(idim+1,jdim+1);

for j = 1:1:jdim+1
    for i=1:1:idim+1
        A = fscanf(fileID,'      %f      %f\n',[1 2]);
%         disp(num2str(A(1)))
        x(i,j) = A(1);
        y(i,j) = A(2);
    end
end
S = geo_cal(x,y,idim,jdim);% calculate the grid's info

% --------end read grid----------

U = zeros(idim,jdim+2,4);% 3-D array to store conservative variables. Virtual points included
UV = zeros(4,idim);% store the virtual points needed for wall boundary condition (Riemann solver)
FH = zeros(idim+1,jdim,4);% 3-D array to store ksi flux.
FV = zeros(idim,jdim+1,4);% 3-D array to store eta flux.
P = zeros(idim,jdim+2,4);% the total flux for time advancement, vol included
rk = [0.1084,0.2602,0.5052,1.0]; % parameters for 4-step explicit time advancement

%--------initialize the field--------

if restart<=0
    INI = initialize(U,UV,S.vect,idim,jdim,M,alpha);
    U = INI.U;
    UV = INI.UV;
    U_OD = U;
else
    U =  ini_restart(U,idim,jdim);
    U_OD = U;
end

%----------initialize end------------


%----------iteration starts----------
for i = 1:1:step
    
    
    disp('------------------------------')
    disp(['Global time step: ',num2str(i)])
    

    
    for k = 1:1:4 % 4th order explicit 
        % calculate the spectra radii
        A = spec_radii(S.edge,S.vect,idim,jdim,U);
        
        % determine the time step
        
        dt = cal_dt(idim,jdim,A,S.vol,CFL);
        
        
        % ksi flux computation
    
        FH = cal_FH(U,FH,S.vect,S.edge,idim,jdim);
    
        % eta flux computation
    
        FV = cal_FV(U,FV,UV,S.vect,S.edge,idim,jdim);% only 2 to jdim are obtained, the 
        %value on 1 and jdim+1 would be dertermined by boundary conditions
        
        % boundary conditions 
        
        [Fwall,Uwall] = bc_wall(U,x,y,idim,jdim);
        V0 = [1;M*cos(alpha/180*pi);M*sin(alpha/180*pi);1/1.4];
        [Ffar,Ufar] = bc_far(U,x,y,idim,jdim,V0);
        
        % add the flux on the boundary to FV array
        
        for m=1:1:idim
            FV(m,jdim+1,:) = Ffar(:,m);
            FV(m,1,:) = Fwall(:,m);
        end
        
        %Calculate the total flux. vol included
        
        P = total_flux(FH,FV,x,y,idim,jdim);
        
        
        %time advancement
        
        U = time_advancement(P,U,U_OD,dt,mode,idim,jdim,k,rk);  %2 to jdim+1 is obtained
        
        %Virtual points update
        
%         SS = virtual_update(U,UV,Ufar,S.vect,idim,jdim);
%         U = SS.U;
%         UV = SS.UV;
        U = virtual_update_old(U,Uwall,Ufar,idim,jdim);
    end
    U_OD = U;
    if mod(i,1)==0
%         U = fake_boundary(U,Ufar,idim,jdim);
        U = fake_boundary_old(U,Uwall,Ufar,idim,jdim);
        Unode = center2node(U,idim,jdim);
        write_tec(Unode,x,y,idim,jdim,i,restep,restart)
    end
%     
%     U = SS.U;
%     UV = SS.UV;
    U = virtual_update_old(U,Uwall,Ufar,idim,jdim);
end

save_for_restart(U_OD,idim,jdim)

end