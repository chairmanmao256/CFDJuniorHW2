function U = fake_boundary(U,Ufar,idim,jdim)
for i=1:1:idim
   U(i,1,:) = (U(i,1,:)+U(i,2,:))*0.5;
   U(i,jdim+2,:) = Ufar(:,i);
end
end