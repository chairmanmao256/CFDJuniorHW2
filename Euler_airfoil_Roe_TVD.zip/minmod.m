function c = minmod(a,b)
dim = size(a);
n = dim(1);
c = zeros(n,1);

for i=1:1:n
   if a(i)*b(i)>0
       c(i) = sign(a(i))*min([abs(a(i)),abs(b(i))]);
   else
       c(i) = 0.0;
   end
end

end