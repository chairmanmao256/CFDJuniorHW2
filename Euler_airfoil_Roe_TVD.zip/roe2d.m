function avg = roe2d(UL,UR)
% calculate the roe average for 2d cases, returns primitive variables
avg = zeros(4,1);


% obtain primitive variables first
VL = decoder2d(UL);
VR = decoder2d(UR);

rl = sqrt(VL(1));
rr = sqrt(VR(1));
HL = (UL(4)+VL(4))/VL(1);
HR = (UR(4)+VR(4))/VR(1);
% HL = 1.4/0.4*VL(4)/VL(1);
% HR = 1.4/0.4*VR(4)/VR(1);


avg(1) = rl*rr;
avg(2) = (rl*VL(2)+rr*VR(2))/(rl+rr);
avg(3) = (rl*VL(3)+rr*VR(3))/(rl+rr);
H = (HL*rl+HR*rr)/(rl+rr);
avg(4) = (H-0.5*(avg(2)*avg(2)+avg(3)*avg(3)))*(1.4-1)/1.4*avg(1);
% avg(4) = H*avg(1)*0.4/1.4;

end