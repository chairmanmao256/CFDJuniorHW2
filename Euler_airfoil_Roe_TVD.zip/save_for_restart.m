function save_for_restart(U,idim,jdim)
fname = 'Restart.dat';
fileID=fopen(fname,'w');
for j=1:jdim+2
    for i=1:idim
        fprintf(fileID,'%15.8f   %15.8f   %15.8f   %15.8f\n',U(i,j,1),U(i,j,2),U(i,j,3),U(i,j,4));
    end
end
fclose(fileID);
end