function A = spec_radii(edge,vect,idim,jdim,U)
% sepctra raddi to calculate dissipation!
A = zeros(idim,jdim,2);


for j = 1:1:jdim
    for i=1:1:idim
        nn = reshape(vect(i,j,:),[8,1]);
        nh1 = nn(1:2,1);
        nh2 = nn(3:4,1);
        nv1 = nn(5:6,1);
        nv2 = nn(7:8,1);
        
        edge4 = reshape(edge(i,j,:),[4,1]);
        lenh1 = edge4(1);
        lenh2 = edge4(2);
        lenv1 = edge4(3);
        lenv2 = edge4(4);
        
        nI = (nh1+nh2)*0.5;
        nJ = (nv1+nv2)*0.5;
        SI = (lenh1+lenh2)*0.5;
        SJ = (lenv1+lenv2)*0.5;
        
        U_current = reshape(U(i,j+1,:),[4,1]);
        V = decoder2d(U_current);
        
        Vni = abs([V(2),V(3)]*nI);
        Vnj = abs([V(2),V(3)]*nJ);
        c = sqrt(1.4*V(4)/V(1));
        
        A(i,j,1) = (Vni+c)*SI;
        A(i,j,2) = (Vnj+c)*SJ;
    end 
end