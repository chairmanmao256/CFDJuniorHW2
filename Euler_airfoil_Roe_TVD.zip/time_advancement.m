function U = time_advancement(P,U,U_OD,dt,mode,idim,jdim,k,rk)

dtt = min(min(dt));% for time accurate computation
e = 0.0;


if mode > 0 %local time step
   for j=1:1:jdim
       for i = 1:1:idim
           Unew = U_OD(i,j+1,:)-rk(k)*dt(i,j)*P(i,j+1,:);
           Unew = reshape(Unew,[4,1]);
           Uold = reshape(U_OD(i,j+1,:),[4,1]);
           err = max(abs(Unew-Uold));
           e = max([e,err]);
           
           U(i,j+1,:) = Unew;
       end
   end
else %global time step(time accurate)
   for j=1:1:jdim
       for i = 1:1:idim
           Unew = U_OD(i,j+1,:)-rk(k)*dtt*P(i,j+1,:);
           Unew = reshape(Unew,[4,1]);
           Uold = reshape(U_OD(i,j+1,:),[4,1]);
           err = max(abs(Unew-Uold));
           e = max([e,err]);
           
           U(i,j+1,:) = Unew;
       end
   end            
end

disp(['Error for time step ',num2str(k),' is:  ',num2str(e)])

end
