function P = total_flux(FH,FV,x,y,idim,jdim)
P = zeros(idim,jdim+2,4);
for j = 1:1:jdim
    for i = 1:1:idim
        diag1 = [x(i+1,j+1) - x(i,j);y(i+1,j+1)-y(i,j)];
        diag2 = [x(i,j+1) - x(i+1,j);y(i,j+1)-y(i+1,j)];
        vol = 0.5*abs(det([diag1,diag2]));
        P(i,j+1,:) = (FH(i+1,j,:)-FH(i,j,:)+FV(i,j+1,:)-FV(i,j,:))/vol;
    end
end

end