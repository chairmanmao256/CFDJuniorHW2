function S = virtual_update(U,UV,Ufar,vect,idim,jdim)
for i=1:1:idim
   % calculate the normal and tangent vector on the boundary
   nn = reshape(vect(i,1,:),[8,1]);
   
%    if i==1
%        n = [0;-1];
%    elseif i==idim
%        n = [0;1];
%    else
%         n = nn(5:6,1);
%    end
   n = nn(5:6,1);
   t = [n(2);-n(1)];
   TT = [n';t']; %transformation matrix
   
   % extract boundary data, two virtual points and two points near the
   % boundary
   U1 = reshape(U(i,2,:),[4,1]);
   U_1 = reshape(U(i,1,:),[4,1]);
   U2 = reshape(U(i,3,:),[4,1]);
   U_2 = UV(:,i);
   
   % decode
   V1 = decoder2d(U1);
   V_1 = V1;
   V2 = decoder2d(U2);
   V_2 = V2;
   
   
   % set symmetric velocity on virtual points -1 and -2
   Vn1 = V1(2)*n(1)+V1(3)*n(2);
   Vn2 = V2(2)*n(1)+V2(3)*n(2);
   Vt1 = V1(2)*t(1)+V1(3)*t(2);
   Vt2 = V2(2)*t(1)+V2(3)*t(2);
   
   Q1 = TT*[-Vn1;Vt1];
   Q2 = TT*[-Vn2;Vt2];
   V_1(2) = Q1(1);
   V_1(3) = Q1(2);
   V_2(2) = Q2(1);
   V_2(3) = Q2(2);
   
   % virtual points at wall updated!
   U_1 = coder2d(V_1);
   U_2 = coder2d(V_2);
   
   U(i,1,:) = U_1;
   UV(:,i) = U_2;
   
   
   % virtual points at farfield updated!
   Ujdim = reshape(U(i,jdim+1,:),[4,1]);
   U(i,jdim+2,:) = 2*Ufar(:,i) - Ujdim;
end
S.U = U;
S.UV = UV;
end