function flux = G(U)
%calculate y flux,conservative input

V = decoder2d(U);
flux = zeros(4,1);
flux(1) = V(1)*V(3);
flux(2) = V(1)*V(2)*V(3); 
flux(3) = V(1)*V(3)*V(3)+V(4);
flux(4) = (U(4)+V(4))*V(3);

end