function [Ffar,Ufar] = bc_far(U,edge,vect,idim,jdim,V0)
Ffar = zeros(4,idim);% store the boundary eta flux
Ufar = zeros(4,idim);% store the boundary conservative variables

for i=1:1:idim
    
    nn = reshape(vect(i,jdim,:),[8,1]);
    nv = nn(7:8,1);
    
    edge4 = reshape(edge(i,jdim,:),[4,1]);
    normnv = edge4(4);
    
    Vn0 = V0(2)*nv(1)+V0(3)*nv(2);
    Vt0 = V0(2)*nv(2)-V0(3)*nv(1);
    a0 = sqrt(1.4*V0(4)/V0(1));
    
    Ustar = reshape(1.5*U(i,jdim+1,:)-0.5*U(i,jdim,:),[4,1]);
    Vstar = decoder2d(Ustar);
    Vn_star = Vstar(2)*nv(1)+Vstar(3)*nv(2);
    Vt_star = Vstar(2)*nv(2)-Vstar(3)*nv(1);
    a_star = sqrt(1.4*Vstar(4)/Vstar(1));
    
%     Vn_true = 0.5*(Vn0+Vn_star)+1/0.4*(a_star - a0);
%     a_true = 0.1*(Vn_star - Vn0)+0.5*(a_star+a0);
    
    if Vn0 < 0 %inlet
        if abs(Vn0)<a0 %subsonic
            Vn_true = 0.5*(Vn0+Vn_star)+1/0.4*(a_star - a0);
            a_true = 0.1*(Vn_star - Vn0)+0.5*(a_star+a0);
            rho_true = (a_true^2*V0(1)^(1.4)/(1.4*V0(4)))^(1/0.4);
            p_true = 1/1.4*a_true*a_true*rho_true;
            Vt_true = Vt0;
        else   %supersonic
            Vn_true = Vn0;
            Vt_true = Vt0;
            rho_true = V0(1);
            p_true = V0(4);
        end
    else %outlet
        if abs(Vn0)<a0   %subsonic
            Vn_true = 0.5*(Vn0+Vn_star)+1/0.4*(a_star - a0);
            a_true = 0.1*(Vn_star - Vn0)+0.5*(a_star+a0);
            rho_true = (a_true^2*Vstar(1)^(1.4)/(1.4*Vstar(4)))^(1/0.4);
            p_true = 1/1.4*a_true*a_true*rho_true;
            Vt_true = Vt_star;
        else   %supersonic
            Vn_true = Vn_star;
            Vt_true = Vt_star;
            rho_true = Vstar(1);
            p_true = Vstar(4);
        end
    end
    
    u_true = nv(1)*Vn_true + nv(2)*Vt_true;
    v_true = nv(2)*Vn_true - nv(1)*Vt_true;
    
    if rho_true<0
       disp(['Error at FAR boundary, rho < 0, index: ',num2str(i)]) 
    end
    if p_true<0
       disp(['Error at FAR boundary, pressure < 0, index: ',num2str(i)]) 
    end
    

    Ufar(:,i) = coder2d([rho_true;u_true;v_true;p_true]);
    Ffar(:,i) = normnv*(F(Ufar(:,i))*nv(1)+G(Ufar(:,i))*nv(2));
%      Ufar(:,i) = coder2d(V0);
%      Ffar(:,i) = normnv*(F(Ufar(:,i))*nv(1)+G(Ufar(:,i))*nv(2));
    
end

end