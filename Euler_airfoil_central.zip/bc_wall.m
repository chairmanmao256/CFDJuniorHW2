function [Fwall,Uwall] = bc_wall(U,edge,vect,idim,jdim)
Fwall = zeros(4,idim);% store the boundary eta flux
Uwall = zeros(4,idim);
V0 = zeros(4,1);% store the primitive variables calculated from inner points
% using boundary condition (true value)

for i=1:1:idim
    nn = reshape(vect(i,1,:),[8,1]);
    nv = nn(5:6,1);
    
    edge4 = reshape(edge(i,1,:),[4,1]);
    normnv = edge4(3);
%     disp(['index:  ',num2str(i),' norm: ',num2str(nv(1)),' ',num2str(nv(2))])
    
%     Ustar = reshape(1.5*U(i,2,:)-0.5*U(i,3,:),[4,1]);
    Ustar = reshape(U(i,2,:),[4,1]);
    Vstar = decoder2d(Ustar);
    Vn_star = Vstar(2)*nv(1)+Vstar(3)*nv(2);
    a_star = sqrt(1.4*Vstar(4)/Vstar(1));
    if Vstar(1)<0
       disp(['Error at WALL boundary interp, rho < 0, index: ',num2str(i)]) 
    end
    if Vstar(4)<0
       disp(['Error at WALL boundary interp, pressure < 0, index: ',num2str(i)]) 
    end
    
    
    
    V0(1) = (0.16*(Vn_star - 2*a_star/0.4)^2*(Vstar(1))^(1.4)/(4*1.4*Vstar(4)))^(2.5);
    V0(2) = Vstar(2)*nv(2)*nv(2) - Vstar(3)*nv(1)*nv(2);
    V0(3) = -Vstar(2)*nv(1)*nv(2) + Vstar(3)*nv(1)*nv(1);
    V0(4) = Vstar(4)*(V0(1)/Vstar(1))^(1.4);
    
    if V0(1)<0
       disp(['Error at WALL boundary, rho < 0, index: ',num2str(i)]) 
    end
    if V0(4)<0
       disp(['Error at WALL boundary, pressure < 0, index: ',num2str(i)]) 
    end
    
    Uwall(:,i) = coder2d(V0);
    Fwall(:,i) = normnv*(F(Uwall(:,i))*nv(1)+G(Uwall(:,i))*nv(2));
end