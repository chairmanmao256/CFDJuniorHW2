function FH = cal_FH_central(U,FH,edge,vect,A,idim,jdim)
% calculate the flux in ksi direction,using central scheme
k2 = 0.5;
k4 = 1/64;

for j=1:1:jdim
    for i=1:1:idim
        % switch cases, take care of boundaries
        if i==1
            UL = reshape(U(idim,j+1,:),[4,1]);
            ULL = reshape(U(idim-1,j+1,:),[4,1]);
            UR = reshape(U(1,j+1,:),[4,1]);
            URR = reshape(U(2,j+1,:),[4,1]);
        elseif i==2
            UL = reshape(U(1,j+1,:),[4,1]);
            ULL = reshape(U(idim,j+1,:),[4,1]);
            UR = reshape(U(2,j+1,:),[4,1]);
            URR = reshape(U(3,j+1,:),[4,1]);
        elseif i==idim
            UL = reshape(U(idim-1,j+1,:),[4,1]);
            ULL = reshape(U(idim-2,j+1,:),[4,1]);
            UR = reshape(U(idim,j+1,:),[4,1]);
            URR = reshape(U(1,j+1,:),[4,1]);
        else
            UL = reshape(U(i-1,j+1,:),[4,1]);
            ULL = reshape(U(i-2,j+1,:),[4,1]);
            UR = reshape(U(i,j+1,:),[4,1]);
            URR = reshape(U(i+1,j+1,:),[4,1]);
        end
        
        VRR = decoder2d(URR);
        VR = decoder2d(UR);
        VL = decoder2d(UL);
        VLL = decoder2d(ULL);
        
        nn = reshape(vect(i,j,:),[8,1]);
        nh1 = nn(1:2,1);
        
        edge4 = reshape(edge(i,j,:),[4,1]);
        lenh1 = edge4(1);
        
        FH0 = (F(0.5*(UR+UL))*nh1(1)+G(0.5*(UR+UL))*nh1(2))*lenh1; % central flux
        
        % artificial viscosity
        if i==1
            t = idim;
        else
            t = i-1;
        end
        
        lambda = (A(t,j,1)+A(i,j,1))*0.5+(A(t,j,2)+A(i,j,2))*0.5; % spectra radii(averaged!)
        gamma1 = abs(VR(4)-2*VL(4)+VLL(4))/(VR(4)+2*VL(4)+VLL(4));
        gamma2 = abs(VRR(4)-2*VR(4)+VL(4))/(VRR(4)+2*VR(4)+VL(4));
        eps2 = k2*max([gamma1,gamma2]);
        eps4 = max([0,k4-eps2]);
        
        D = lambda*(eps2*(UR-UL)-eps4*(URR-3*UR+3*UL-ULL));
        
        FH(i,j,:) = FH0 - D;
    end
    FH(idim+1,j,:) = FH(1,j,:);
end