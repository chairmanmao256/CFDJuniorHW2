function FV = cal_FV_central(U,FV,edge,vect,A,idim,jdim)
% calculate the flux in eta direction,using central scheme
k2 = 0.5;
k4 = 1/64;


for j = 2:1:jdim  % flux on the boundary is not calculated, index is the volume index!!
    for i=1:1:idim
        URR = reshape(U(i,j+2,:),[4,1]);
        UR = reshape(U(i,j+1,:),[4,1]);
        UL = reshape(U(i,j,:),[4,1]);
        ULL = reshape(U(i,j-1,:),[4,1]);
        
        VRR = decoder2d(URR);
        VR = decoder2d(UR);
        VL = decoder2d(UL);
        VLL = decoder2d(ULL);
        
        nn = reshape(vect(i,j,:),[8,1]);
        nv1 = nn(5:6,1);
        
        edge4 = reshape(edge(i,j,:),[4,1]);
        lenv1 = edge4(3);
        
        FV0 = (F(0.5*(UR+UL))*nv1(1)+G(0.5*(UR+UL))*nv1(2))*lenv1; % central flux
        
        % artificial viscosity
        lambda = (A(i,j,1)+A(i,j-1,1))*0.5+(A(i,j,2)+A(i,j-1,2))*0.5; % spectra radii(averaged!)
        gamma1 = abs(VR(4)-2*VL(4)+VLL(4))/(VR(4)+2*VL(4)+VLL(4));
        gamma2 = abs(VRR(4)-2*VR(4)+VL(4))/(VRR(4)+2*VR(4)+VL(4));
        eps2 = k2*max([gamma1,gamma2]);
        eps4 = max([0,k4-eps2]);
        
        D = lambda*(eps2*(UR-UL)-eps4*(URR-3*UR+3*UL-ULL));
        
        FV(i,j,:) = FV0 - D;
    end
end

end