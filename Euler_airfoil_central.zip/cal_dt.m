function dt = cal_dt(idim,jdim,A,vol,CFL)
dt = zeros(idim,jdim);

for i=1:1:idim
    for j=1:1:jdim
        % obtain primitive variables from conservative variables
        
        dt(i,j) = CFL*vol(i,j)/(A(i,j,1)+A(i,j,2));
        
        if imag(dt(i,j))>1e-8
            disp(['Error!Complex time step at  ',num2str(i),' ',num2str(j)])
        end

    end
end
        disp(['Minimum dt: ',num2str(min(min(dt)))])
        disp(['Maximum dt: ',num2str(max(max(dt)))])
end