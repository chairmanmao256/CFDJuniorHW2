function Unode = center2node(U,idim,jdim)
Unode = zeros(idim+1,jdim+1,4);

for j=2:1:jdim % interior nodes
    for i=1:1:idim+1 % node's index is used
        if i==1
            k = idim;
            t = 1;
        elseif i==idim+1
            k = idim;
            t = 1;
        else
            k = i-1;
            t = i;
        end
        Unode(i,j,:) = 0.25*(U(t,j+1,:)+U(t,j,:)+U(k,j+1,:)+U(k,j,:));
    end
end

for i=1:1:idim+1 % treat boundary nodes now
    if i==1
        k = idim;
        t = 1;
    elseif i==idim+1
        k = idim;
        t = 1;
    else
        k = i-1;
        t = i;
    end
    Unode(i,1,:) = 0.5*(U(t,1,:)+U(k,1,:));
    Unode(i,jdim+1,:) = 0.5*(U(t,jdim+2,:)+U(k,jdim+2,:));
end

end