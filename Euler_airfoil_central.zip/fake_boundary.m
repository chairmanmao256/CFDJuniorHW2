function U = fake_boundary(U,Uwall,Ufar,idim,jdim)
for i=1:1:idim
   U(i,1,:) = Uwall(:,i);
   U(i,jdim+2,:) = Ufar(:,i);
end
end