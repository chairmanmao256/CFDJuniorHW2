function S = geo_cal(x,y,idim,jdim)
% calculate the normal vectors and the edge length
vect = zeros(idim,jdim,8);% store the normal vectors(nh1,nh2,nv1,nv2)
edge = zeros(idim,jdim,4);% store the edge length(nh1,nh2,nv1,nv2)
vol = zeros(idim,jdim);%store the volume of the control volume


for j = 1:1:jdim
    for i=1:1:idim
        nv1 = [y(i,j) - y(i+1,j);x(i+1,j)-x(i,j)];
        nv2 = [y(i,j+1) - y(i+1,j+1);x(i+1,j+1)-x(i,j+1)];
        normv1 = sqrt(nv1(1)*nv1(1)+nv1(2)*nv1(2));
        normv2 = sqrt(nv2(1)*nv2(1)+nv2(2)*nv2(2));
        nv1 = nv1/normv1;
        nv2 = nv2/normv2;
        
        nh1 = [y(i,j+1)-y(i,j);x(i,j)-x(i,j+1)];
        nh2 = [y(i+1,j+1)-y(i+1,j);x(i+1,j)-x(i+1,j+1)];
        normh1 = sqrt(nh1(1)*nh1(1)+nh1(2)*nh1(2));
        normh2 = sqrt(nh2(1)*nh2(1)+nh2(2)*nh2(2));
        nh1 = nh1/normh1;
        nh2 = nh2/normh2;
        
        diag1 = [x(i+1,j+1)-x(i,j);y(i+1,j+1)-y(i,j)];
        diag2 = [x(i,j+1)-x(i+1,j);y(i,j+1)-y(i+1,j)];
        vol(i,j) = abs(det([diag1,diag2]))*0.5;
        
        
        vect(i,j,:) = [nh1;nh2;nv1;nv2];
        edge(i,j,:) = [normh1;normh2;normv1;normv2];
       
    end 
end

S.vect = vect;
S.edge = edge;
S.vol = vol;
end