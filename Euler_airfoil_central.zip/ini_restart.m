function U = ini_restart(U,idim,jdim)
fileID=fopen('Restart.dat','r');

for j=1:1:jdim+2
    for i=1:1:idim
        A = fscanf(fileID,'%f   %f   %f   %f\n',[1 4]);
        U(i,j,1) = A(1);
        U(i,j,2) = A(2);
        U(i,j,3) = A(3);
        U(i,j,4) = A(4);
    end
end

end