function U = initialize(idim,jdim,M,alpha)
alpha = alpha*pi/180;% degree to rad
U = zeros(idim,jdim+2,4);
%calculate primitive variables
V(1) = 1.0;
V(2) = M*cos(alpha);
V(3) = M*sin(alpha);
% V(2) = 0.0;
% V(3) = 0.0;
V(4) = 1.0/1.4;

U0 = coder2d(V);

for i=1:1:idim
    for j=1:1:jdim+2
        U(i,j,:)=U0;
    end
end
end