function P = total_flux(FH,FV,vol,idim,jdim)
P = zeros(idim,jdim+2,4);
for j = 1:1:jdim
    for i = 1:1:idim
        P(i,j+1,:) = (FH(i+1,j,:)-FH(i,j,:)+FV(i,j+1,:)-FV(i,j,:))/vol(i,j);
    end
end

end