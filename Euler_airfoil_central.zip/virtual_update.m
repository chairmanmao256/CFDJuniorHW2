function U = virtual_update(U,Uwall,Ufar,idim,jdim)
for i=1:1:idim
   U2 = reshape(U(i,2,:),[4,1]);
   U(i,1,:) = 2*Uwall(:,i) -U2 ;
   
   Ujdim = reshape(U(i,jdim+1,:),[4,1]);
   U(i,jdim+2,:) = 2*Ufar(:,i) - Ujdim;
end
end