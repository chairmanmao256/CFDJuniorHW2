function write_tec(U,x,y,idim,jdim,q,restep,restart)
% idim = idim+1;
% jdim = jdim+1;
if restart>0
    q = q+restep;
    q = num2str(q);
else
    q = num2str(q);
end

fname = [q,'NACA0012.plt'];
fileID=fopen(fname,'w');
fprintf(fileID,'variables=x,y,rho,u,v,p\n');
fprintf(fileID,' zone i=%d,j=%d,f=point\n',idim+1,jdim+1);

for j=1:jdim+1
    for i=1:idim+1
        V = decoder2d(reshape(U(i,j,:),[4,1]));
        fprintf(fileID,'%15.8f   %15.8f   %15.8f   %15.8f   %15.8f   %15.8f\n',x(i,j),y(i,j),V(1),V(2),V(3),V(4));
    end
end

fclose(fileID);

end